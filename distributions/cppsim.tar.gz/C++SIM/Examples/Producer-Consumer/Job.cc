/*
 * Copyright (C) 1994, 1995, 1996, 1997
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: Job.cc,v 1.1 1996/12/09 10:10:07 nmcl Exp $
 */

#ifndef BOOLEAN_H_
#  include <Common/Boolean.h>
#endif

#ifndef JOB_H_
#  include "Job.h"
#endif

Job::Job ()
{
}

Job::~Job ()
{
}
