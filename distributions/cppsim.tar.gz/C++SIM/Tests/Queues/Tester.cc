/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 *
 * $Id: Tester.cc,v 1.10 1996/12/04 15:08:04 nmcl Exp $
 */

#include <iostream.h>

#ifndef RESOURCE_H_
#  include <Common/Resource.h>
#endif

#ifndef TESTER_H_
#  include "Tester.h"
#endif

#ifndef DUMMYPROCESS_H_
#  include "DummyProcess.h"
#endif

#ifdef TESTQUEUE

#ifndef CONFIGURE_H_
#  include <Config/Configure.h>
#endif

#ifdef ProcessList_Queue
#  ifndef PROCESSLIST_H_
#    include "ProcessList.h"
#  endif
#endif

#ifdef ProcessHeap_Queue
#  ifndef PROCESSHEAP_H_
#    include "ProcessHeap.h"
#  endif
#endif

#ifdef Calendar_Queue
#  ifndef CALENDAR_H_
#    include "Calendar.h"
#  endif
#endif

#ifdef HasedList_Queue
#  ifndef HASHEDLIST_H_
#    include "HashedList.h"
#  endif
#endif


extern Queue_Type ReadyQueue;

#endif


Tester::Tester (long elements, StreamType st)
               : number(elements),
                 hi(1000.0),
                 lo(10.0),
                 mean(20.0),
                 std(5.0),
                 streamType(st),
                 head(0)
{
    us = (UniformStream*) 0;
    ns = (NormalStream*) 0;
    es = (ExponentialStream*) 0;

    switch(st)
    {
    case UNIFORM:
        us = new UniformStream(lo, hi);
	break;
    case NORMAL:
	ns = new NormalStream(mean, std);
	break;
    case EXPONENTIAL:
	es = new ExponentialStream(mean);
	break;
    }
}

Tester::~Tester ()
{
    if (us)
        delete us;
    if (ns)
        delete ns;
    if (es)
        delete es;
}

/*
 * We only want to test the queue, so no need to start
 * the scheduler.
 */

void Tester::Body ()
{
    DummyProcess *dp = (DummyProcess*) 0;
    int i;
    
    // put half of the required elements in the list

    for (i = 0; i < number; i++)
    {
        dp = new DummyProcess;

#ifndef NO_RESOURCE
        Resource::ref(dp);
#endif

	switch(streamType)
	{
	case UNIFORM:
	    dp->ActivateAt((*us)());
	    break;
	case NORMAL:
	    dp->ActivateAt((*ns)());
	    break;
	case EXPONENTIAL:
	    dp->ActivateAt((*es)());
	    break;
	}

	dp->next = head;
	head = dp;
    }

#ifdef TESTQUEUE
#ifdef DEBUG
    cout << "The list structure is:" << ReadyQueue << endl;
#endif

    for (i = 0; i < number; i++)
    {
	dp = (DummyProcess*) ReadyQueue.Remove();
#ifdef DEBUG
	cout << "Removed " << dp->evtime() << endl;
#endif
	if (dp)
#ifndef NO_RESOURCE
	    Resource::unref(dp);
#else
	    delete dp;
#endif
    }
#else
    DummyProcess* trail = (DummyProcess*) 0;
    
    dp = head;
    for (i = 0; i < number; i++)
    {
        dp->Cancel();
	trail = dp;
	dp = dp->next;

#ifndef NO_RESOURCE
        Resource::unref(trail);
#else
	delete trail;
#endif
    }
#endif

    Thread::mainResume();
}

void Tester::Await ()
{
    Resume();
    Thread::Self()->Suspend();
}

void Tester::Exit ()
{
    Thread::Exit();
}

