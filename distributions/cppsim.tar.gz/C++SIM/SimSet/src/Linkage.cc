/*
 * Copyright (C) 1994
 *
 * Department of Computing Science,
 * The University,
 * Newcastle upon Tyne,
 * UK.
 */


/*
 * This class defines the core element within SIMSET.
 */


#ifndef LINKAGE_H_
#  include <SimSet/Linkage.h>
#endif


Linkage::Linkage () {}

Linkage::~Linkage () {};
